import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLmetodos {
    public static final String ruta = "C:\\Users\\sauli\\Documents\\NetBeansProjects\\RepositorioPOO\\Practica 8\\practica8.xml";
    private DocumentBuilderFactory docFactory;
    private DocumentBuilder docBuilder;
    
    public void leerXML(){
        try {
            this.docFactory=DocumentBuilderFactory.newInstance();
            this.docBuilder= docFactory.newDocumentBuilder();
            Document doc = this.docBuilder.parse(new File(ruta));
            doc.getDocumentElement().normalize();
            
            NodeList listaContactos = doc.getElementsByTagName("Contacto");
            
            for (int i = 0; i < listaContactos.getLength(); i++) {
                Node nodo = listaContactos.item(i);
                if(nodo.getNodeType() == Node.ELEMENT_NODE){
                    Element e = (Element) nodo;
                    NodeList childs = e.getChildNodes();
                    for (int j = 0; j < childs.getLength(); j++) {
                        Node child = childs.item(j);
                        if(child.getNodeType()== Node.ELEMENT_NODE){
                            Element hijo = (Element) child;
                            System.out.println(hijo.getNodeName()+": "+hijo.getTextContent());
                        }
                    }
                    System.out.println("");
                }
            }
        }catch (ParserConfigurationException | SAXException | IOException ex) {
            System.out.println(ex);
        }
    }
}

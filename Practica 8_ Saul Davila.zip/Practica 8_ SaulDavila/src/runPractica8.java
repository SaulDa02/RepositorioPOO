
import java.io.File;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class runPractica8 {

    public static final String ruta = "C:\\Users\\sauli\\Documents\\NetBeansProjects\\RepositorioPOO\\Practica 8\\practica8.xml";

    public static void main(String argv[]) {
        
        Scanner sc = new Scanner(System.in);
        XMLmetodos obj = new XMLmetodos();
        
        try {
            
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document document = documentBuilder.newDocument();

            //root Element
            Element root = document.createElement("Agenda");
            document.appendChild(root);

    //Contacto Element 1
            Element contacto1 = document.createElement("Contacto");
            root.appendChild(contacto1);

            //Mandar atributo al elemento
            Attr attr1 = document.createAttribute("id");
            attr1.setValue("1");
            contacto1.setAttributeNode(attr1);

            System.out.print("Ingrese el nombre: ");
            
            //nombre Element
            Element nombre1 = document.createElement("Nombre");
            nombre1.appendChild(document.createTextNode(sc.nextLine()));
            contacto1.appendChild(nombre1);
            
            System.out.print("Ingrese el apellido paterno: ");
            
            //apellidoP Element
            Element apellidoP1 = document.createElement("ApellidoP");
            apellidoP1.appendChild(document.createTextNode(sc.nextLine()));
            contacto1.appendChild(apellidoP1);
            
            System.out.print("Ingrese el telefono: ");
            
            //telefono Element
            Element telefono1 = document.createElement("Telefono");
            telefono1.appendChild(document.createTextNode(sc.nextLine()));
            contacto1.appendChild(telefono1);
            
            System.out.print("Ingrese el email: ");

            //email Element
            Element email1 = document.createElement("Email");
            email1.appendChild(document.createTextNode(sc.nextLine()));
            contacto1.appendChild(email1);

    //Contacto Element 2
            Element contacto2 = document.createElement("Contacto");
            root.appendChild(contacto2);

            //Mandar atributo al elemento
            Attr attr2 = document.createAttribute("id");
            attr2.setValue("2");
            contacto2.setAttributeNode(attr2);

            System.out.print("\nIngrese el nombre: ");
            
            //nombre Element
            Element nombre2 = document.createElement("Nombre");
            nombre2.appendChild(document.createTextNode(sc.nextLine()));
            contacto2.appendChild(nombre2);

            System.out.print("Ingrese el apellido paterno: ");
            
            //apellidoP Element
            Element apellidoP2 = document.createElement("ApellidoP");
            apellidoP2.appendChild(document.createTextNode(sc.nextLine()));
            contacto2.appendChild(apellidoP2);

            System.out.print("Ingrese el telefono: ");
            
            //telefono Element
            Element telefono2 = document.createElement("Telefono");
            telefono2.appendChild(document.createTextNode(sc.nextLine()));
            contacto2.appendChild(telefono2);

            System.out.print("Ingrese el email: ");
            
            //email Element
            Element email2 = document.createElement("Email");
            email2.appendChild(document.createTextNode(sc.nextLine()));
            contacto2.appendChild(email2);
            
            //Archivo XML
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StreamResult streamResult = new StreamResult(new File(ruta));
            
            transformer.transform(domSource, streamResult);
            
            
        } catch (ParserConfigurationException | TransformerException ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println("\n-------------------------------------");
        
        obj.leerXML();
    }
}

import java.util.Random;
import java.util.Scanner;

public class Operaciones {

    Scanner s = new Scanner(System.in);

    void primera() {
        System.out.println("\nSeleccione una opcion:\n1.- int to String\n2.- String to int\n");
        int op;
        op = s.nextInt();
        if (op == 1) {
            aString();
        }
        if (op == 2) {
            aInt();
        }
    }

    void segunda() {
        System.out.println("\nIngrese una serie de numeros (separados por espacios):");
        String cadena;
        int suma = 0;
        cadena = s.nextLine();
        String numeros[] = cadena.split(" ");

        for (String num : numeros) {
            int enteros = Integer.parseInt(num);
            suma += enteros;
        }
        System.out.println("La suma de los numeros es:\n" + suma);
    }

    void tercera() {
        int num1, num2, num3, cont=0;
        System.out.println("\nIntroduce la cantidad de numeros a imprimir: ");
        num1 = s.nextInt();
        System.out.println("Introduce el numero con el que deben terminar los numeros: ");
        num2 = s.nextInt();
        System.out.println("Introduce hasta cual entero generar los numeros: ");
        num3 = s.nextInt();
        
        Random num = new Random();
        System.out.println("\nLista de numeros: ");
        for (int i = 0; i < num1; i++) {
            int x;
            x = num.nextInt(1+num3);
            System.out.println(x);
            if((x%10)==num2){
                cont+=1;
            }
        }
        System.out.println("\nNumero con terminacion "+num2+": \n"+cont);
    }

    void cuarta() {
        int num1 = 0, num2 = 0;
        System.out.println("\nIngrese el numero inicial: ");
        num1 = s.nextInt();
        System.out.println("\nIngrese el numero final: ");
        num2 = s.nextInt();
        if (num1 == num2) {
            System.out.println("\nLista de numeros:\n" + num1);
        }
        if (num1 > num2) {
            System.out.println("\nLista de numeros:");
            while (num1 != num2) {
                System.out.println(num1);
                num1 = num1 - 1;
            }
            System.out.println(num1);
        }
        if (num1 < num2) {
            System.out.println("\nLista de numeros:");
            while (num1 != num2) {
                System.out.println(num1);
                num1 = num1 + 1;
            }
            System.out.println(num1);
        }
    }

    void quinta() {
        int num1 = 0, num2 = 0;
        System.out.println("\nIngrese el numero inicial: ");
        num1 = s.nextInt();
        System.out.println("\nIngrese el numero final: ");
        num2 = s.nextInt();
        if (num1 == num2) {
            System.out.println("\nLista de numeros:\n" + num1);
        }
        if (num1 > num2) {
            System.out.println("\nLista de numeros:");
            do {
                System.out.println(num1);
                num1 = num1 - 1;
            } while (num1 != num2);
            System.out.println(num1);
        }
        if (num1 < num2) {
            System.out.println("\nLista de numeros:");
            do {
                System.out.println(num1);
                num1 = num1 + 1;
            } while (num1 != num2);
            System.out.println(num1);
        }
    }

    void sexta() {
        int num1 = 0, num2 = 0;
        System.out.println("\nIngrese el numero inicial: ");
        num1 = s.nextInt();
        System.out.println("\nIngrese el numero final: ");
        num2 = s.nextInt();
        if (num1 == num2) {
            System.out.println("\nLista de numeros:\n" + num1);
        }
        if (num1 > num2) {
            System.out.println("\nLista de numeros:");
            for (int i = num1; num2 != i; i--) {
                System.out.println(i);
                num1 = i;
            }
            num1 -= 1;
            System.out.println(num1);
        }
        if (num1 < num2) {
            System.out.println("\nLista de numeros:");
            for (int i = num1; num2 != i; i++) {
                System.out.println(i);
                num1 = i;
            }
            num1 += 1;
            System.out.println(num1);
        }
    }

    void septima() {
        String numromano;
        int num;

        System.out.println("\nIngrese un numero del 1 al 9999: ");
        num = s.nextInt();

        int[] numeros = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] letras = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

        StringBuilder romano = new StringBuilder();

        for (int i = 0; i < numeros.length; i++) {
            while (num >= numeros[i]) {
                num -= numeros[i];
                romano.append(letras[i]);
                System.out.println(i);
            }
        }
        numromano = romano.toString();

        System.out.println("\nNumero en romano:\n" + numromano);
    }

    void aString() {
        int x;
        System.out.println("\nIngrese el numero: ");
        x = s.nextInt();
        Integer y = new Integer(x);
        System.out.println("De int a String:\n" + y.toString());
    }

    void aInt() {
        String x;
        System.out.println("\nIngrese la cadena (de 1 numero): ");
        x = s.next();
        int y;
        y = Integer.parseInt(x);
        System.out.println("De String a int:\n" + y);
    }

}

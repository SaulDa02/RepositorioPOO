
import java.util.Scanner;

public class Main12 {

    public static void main(String[] args) {
        Operaciones ob = new Operaciones();
        Scanner s = new Scanner(System.in);
        int op = 0;
        do {
            System.out.println("Seleccione una opcion: ");
            System.out.println("1.- Convertir int to String o String to int");
            System.out.println("2.- Suma de N numeros dados");
            System.out.println("3.- Generar X numeros random y contar cuantos terminan con Y numero");
            System.out.println("4.- Mostrar los numeros de X a Y mediante while");
            System.out.println("5.- Mostrar los numeros de X a Y mediante do-While");
            System.out.println("6.- Mostrar los numeros de X a Y mediante for");
            System.out.println("7.- Convertir X numero a numeracion rormana");
            System.out.println("8.- Salir\n");
            op = s.nextInt();
            switch (op) {
                case 1:
                    ob.primera();
                    break;
                case 2:
                    ob.segunda();
                    break;
                case 3:
                    ob.tercera();
                    break;
                case 4:
                    ob.cuarta();
                    break;
                case 5:
                    ob.quinta();
                    break;
                case 6:
                    ob.sexta();
                    break;
                case 7:
                    ob.septima();
                    break;
                case 8:
                    break;
            }
            System.out.println("\n\n\n");
        } while (op != 8);
    }
}

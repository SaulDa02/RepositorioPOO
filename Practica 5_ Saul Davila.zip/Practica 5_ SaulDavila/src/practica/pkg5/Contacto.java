
package practica.pkg5;

public class Contacto {

    
    public String getNom() {
        return nom;
    }
    
    public void setNom(String nom) {
        this.nom = nom;
    }
   
    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public long getTel() {
        return tel;
    }

    public void setTel(long tel) {
        this.tel = tel;
    }
    
    private String nom;
    private String mail;
    private long tel;
    
    public void agregarCont(){
        
    }
    
    public void eliminarCont(){
        
    }
    
}

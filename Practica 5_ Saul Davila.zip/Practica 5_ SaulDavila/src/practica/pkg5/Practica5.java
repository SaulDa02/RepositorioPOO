package practica.pkg5;

import practica.pkg5.Contacto;
import java.util.Scanner;

public class Practica5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Telefono[] t1 = new Telefono[5];
        Contacto[][] c1 = new Contacto[5][5];

        Telefono tel1 = new Telefono();
        Telefono tel2 = new Telefono();
        Telefono tel3 = new Telefono();
        Telefono tel4 = new Telefono();
        Telefono tel5 = new Telefono();

        t1[0] = tel1;
        t1[1] = tel2;
        t1[2] = tel3;
        t1[3] = tel4;
        t1[4] = tel5;

        //Captura de datos telefonos y contactos
        for (int i = 0; i < 5; i++) {
            int precio;
            String color, marca, modelo;

            System.out.print("Telefono " + (i + 1) + "\nMarca: ");
            marca = sc.next();
            System.out.print("Modelo: ");
            modelo = sc.next();
            System.out.print("Color: ");
            color = sc.next();
            System.out.print("Precio: ");
            precio = sc.nextInt();            

            t1[i].setMarca(marca);
            t1[i].setModelo(modelo);
            t1[i].setPrecio(precio);
            t1[i].setColor(color);

            for (int j = 0; j < 5; j++) {
                c1[i][j] = new Contacto();

                long telefono;
                String nombre, mail;

                System.out.print("\n\tContacto " + (j + 1) + "\n\tNumero: ");
                telefono = sc.nextLong();
                System.out.print("\tNombre: ");
                nombre = sc.next();
                System.out.print("\tMail: ");
                mail = sc.next();

                c1[i][j].setTel(telefono);
                c1[i][j].setNom(nombre);
                c1[i][j].setMail(mail);
            }
        }

        //Impresión de datos de telefonos y contactos
        for (int i = 0; i < 5; i++) {
            System.out.print("\n----------------------------------------------------------------------------------------------");
            System.out.println("\nTelefono Marca: " + (t1[i].getMarca()) + ". Precio: " + (t1[i].getPrecio()) + ". Modelo: " + (t1[i].getModelo()) + ". Color: " + (t1[i].getColor()) + ". Conexion: " + (t1[i].setPasswordWF("contrasena")) + "\n\nLISTA DE CONTACTOS");

            for (int j = 0; j < 5; j++) {
                System.out.println("Contacto " + (j + 1) + ": Numero: " + (c1[i][j].getTel()) + ",\tNombre: " + (c1[i][j].getNom()) + ",\tMail: " + (c1[i][j].getMail()) + ".");
            }

            int op;
            t1[i].encender();
            System.out.print("\nIngresa el contacto a iniciar llamada: ");
            op = sc.nextInt();
            System.out.println("Llamando a " + (c1[i][op - 1].getTel()) + "\n");
            System.out.print("Ingresa el contacto a iniciar otra llamada: ");
            op = sc.nextInt();
            System.out.println((t1[i].iniciarLlamada(c1[i][op - 1])) + "\n");
            System.out.println(t1[i].finalizarLlamada() + "\n");
            System.out.println(t1[i].apagar());
        }
    }
}


package practica.pkg5;

public class Telefono extends DispositivoElectronico implements IWifiConection{

    private int precio;
    private String color;
    private String marca;
    private String modelo;


    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    @Override
    public void encender() {
        System.out.println("\nTelefono encendido");
    }

    @Override
    public String apagar() {
        return " Telefono apagado\n";
    }
    
    @Override
    public String setPasswordWF(String psswd) {
        if(psswd.isEmpty()==true){
            return " Desconectada ";
        }else{
            return " Conectada ";
        }
    }
    
    public long iniciaLlamada(long numero){
        return numero;
    }
    
    public String iniciarLlamada(Contacto contacto){
        return "Llamando a: "+contacto.getNom();
    }
    
    public String finalizarLlamada(){
        return "Llamada finalizada";
    }
    
    //Atributos: Marca, precio, modelo, color
    //Metodos: IniciarLlamada(numero), Iniciar Llamada(NombreContacto), FinalizaLlamada
    
}


package practica.pkg5;

public abstract class DispositivoElectronico {
    
    public abstract void encender();
    
    public abstract String apagar();
    
}

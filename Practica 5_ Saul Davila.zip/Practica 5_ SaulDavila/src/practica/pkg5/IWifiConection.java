
package practica.pkg5;

public interface IWifiConection {
    
    public String setPasswordWF(String psswd); //validar la contrseña
    
}

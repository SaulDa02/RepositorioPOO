
public interface IOperacionesAritmeticas {
    
    public float suma(float a, float b);
    
    public float resta(float a, float b);
    
    public float multiplicacion(float a, float b);
    
    public float division(float a, float b);
            
}

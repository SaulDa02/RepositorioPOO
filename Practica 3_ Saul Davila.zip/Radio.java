
public class Radio extends DispositivoElectronico implements IFunciones, IConfiguracionMenu{
    
    //DispositivoElectronico
    @Override
    public void encender() {
        System.out.println("Radio encendido. ");
    }

    @Override
    public String apagar() {
        return "Radio apagado. ";
    }

    //IFunciones
    @Override
    public String cambioCanal() {
        return "Radio Cambio de Canal";
    }

    @Override
    public void subirVolumen() {
        System.out.println("Radio subir volumen");
    }

    @Override
    public void bajarVolumen() {
        System.out.println("Radio bajar volumen");
    }
    
    //IConfiguracionMenu
    @Override
    public void configurarMenu() {
        System.out.println("Menu Radio Configurado"); 
    }
}

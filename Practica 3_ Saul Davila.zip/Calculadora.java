
public class Calculadora extends DispositivoElectronico implements IOperacionesAritmeticas, IConfiguracionMenu{
    //DispositivoElectronico
    @Override
    public void encender() {
        System.out.println("Calculadora encendida. ");
    }

    @Override
    public String apagar() {
        return "Calculadora apagada. ";
    }

    //IOperacionesAritmeticas
    @Override
    public float suma(float a, float b) {
        float suma;
        suma=a+b;
        return suma;
    }

    @Override
    public float resta(float a, float b) {
        float resta;
        resta=a-b;
        return resta;
    }

    @Override
    public float multiplicacion(float a, float b) {
        float multiplicacion;
        multiplicacion=a*b;
        return multiplicacion;
    }

    @Override
    public float division(float a, float b) {
        float division;
        division=a/b;
        return division;
    }

    //IConfiguracionMenu
    @Override
    public void configurarMenu() {
        System.out.println("Menu Calculadora Configurado"); 
    }
}

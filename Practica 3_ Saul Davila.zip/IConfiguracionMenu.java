
public interface IConfiguracionMenu {
    
    public void configurarMenu();
    
}

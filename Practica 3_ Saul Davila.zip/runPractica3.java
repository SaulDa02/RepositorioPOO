import java.util.Scanner;

public class runPractica3 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        float num1, num2;
        
        Radio radio = new Radio();
        Television tele = new Television();
        Calculadora calcu = new Calculadora();
        
        calcu.setMarca("Casio");
        calcu.setModelo("2747");
        calcu.setColor("Negro");
        
        tele.setMarca("LG");
        tele.setModelo("Ai Thinq 4K Oled65C1Psa LG");
        tele.setColor("Azul");
        
        radio.setMarca("Revo Radio");
        radio.setModelo("Revo SuperConnect");
        radio.setColor("Cafe");
        
        System.out.println("-------------------------------");
        
        System.out.println("Marca:  "+tele.getMarca());
        System.out.println("Modelo: "+tele.getModelo());
        System.out.println("Color:  "+tele.getColor());
        tele.encender();
        System.out.println(tele.cambioCanal());
        tele.configurarMenu();
        tele.subirVolumen();
        tele.subirVolumen();
        tele.bajarVolumen();
        System.out.println(tele.apagar());
        System.out.println("-------------------------------");
        
        System.out.println("Marca:  "+radio.getMarca());
        System.out.println("Modelo: "+radio.getModelo());
        System.out.println("Color:  "+radio.getColor());
        radio.encender();
        System.out.println(radio.cambioCanal());
        radio.bajarVolumen();
        radio.configurarMenu();
        System.out.println(radio.cambioCanal());
        radio.bajarVolumen();
        radio.subirVolumen();
        System.out.println(radio.apagar());
        System.out.println("-------------------------------");
        
        System.out.println("Marca:  "+calcu.getMarca());
        System.out.println("Modelo: "+calcu.getModelo());
        System.out.println("Color:  "+calcu.getColor());
        calcu.encender();
        calcu.configurarMenu();
        System.out.print("Ingrese un número:   ");
        num1 = scan.nextFloat();
        System.out.print("Ingrese otro número: ");
        num2 = scan.nextFloat();
        System.out.println("Suma:           "+calcu.suma(num1, num2));
        System.out.println("Resta:          "+calcu.resta(num1, num2));
        System.out.println("Multiplicacion: "+calcu.multiplicacion(num1, num2));
        System.out.println("Division:       "+calcu.division(num1, num2));
        System.out.println(calcu.apagar());
        System.out.println("-------------------------------");
        
    }
}

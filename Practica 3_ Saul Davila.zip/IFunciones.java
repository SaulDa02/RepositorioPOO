
public interface IFunciones {
    
    public String cambioCanal();
    
    public void subirVolumen();
    public void bajarVolumen();
}

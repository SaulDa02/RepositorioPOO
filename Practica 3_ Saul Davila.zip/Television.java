
public class Television extends DispositivoElectronico implements IFunciones, IConfiguracionMenu{

    //DispositivoElectronico
    @Override
    public void encender() {
        System.out.println("Television encendida. ");
    }

    @Override
    public String apagar() {
        return "Television apagada. ";
    }

    //IFunciones
    @Override
    public String cambioCanal() {
        return "Television Cambio de Canal";
    }

    @Override
    public void subirVolumen() {
        System.out.println("Television Subir volumen");
    }

    @Override
    public void bajarVolumen() {
        System.out.println("Television bajar volumen");
    }

    //IConfiguracionMenu
    @Override
    public void configurarMenu() {
        System.out.println("Menu Television Configurado"); 
    }
    
}


public interface IAvanzar {
    
    String avanzar(int gasolina);
    
}

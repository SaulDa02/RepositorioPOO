
public class Automovil extends Transporte implements IFrenar, IAvanzar{
    private String marca, modelo, precio, color;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    @Override
    public void Encender() {
        System.out.println("El automovil enciende");
    }
    
    public void Vuelta(String derecha_izquierda){
        System.out.println("Vuelta "+derecha_izquierda);
    };

    @Override
    public void frenar() {
        System.out.println("El automovil frena");
    }

    @Override
    public String avanzar(int gasolina) {
        return "El automovil avanza "+(gasolina*10)+" kilometros";
    }
    
}

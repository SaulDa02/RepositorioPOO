
public abstract class Transporte {
    
    public abstract void Encender();
    
    public void Avanzar(){
        System.out.println("El transporte avanza");
    }
    
}


public interface IFrenar {
    
    void frenar();
    
}


import java.util.ArrayList;
import java.util.Scanner;

public class runMain {

    public static void main(String[] args) {
        String marca, modelo, precio, color;

        Scanner sc = new Scanner(System.in);
        ArrayList<Automovil> auto = new ArrayList<Automovil>(10);
        Automovil[] coche = new Automovil[10];

        for (int i = 0; i < coche.length; i++) {
            coche[i] = new Automovil();
            System.out.println("Automovil " + (i + 1));
            System.out.print("Marca: ");
            marca = sc.next();
            coche[i].setMarca(marca);
            System.out.print("Modelo: ");
            modelo = sc.next();
            coche[i].setModelo(modelo);
            System.out.print("Precio: ");
            precio = sc.next();
            coche[i].setPrecio(precio);
            System.out.print("Color: ");
            color = sc.next();
            coche[i].setColor(color);
            System.out.println("");
        }

        auto.add(coche[0]);
        auto.add(coche[1]);
        auto.add(coche[2]);
        auto.add(coche[3]);
        auto.add(coche[4]);
        auto.add(coche[5]);
        auto.add(coche[6]);
        auto.add(coche[7]);
        auto.add(coche[8]);
        auto.add(coche[9]);

        System.out.println("COCHES: ");
        for (int i = 0; i < auto.size(); i++) {
            System.out.println("\n*****AUTOMOVIL " + auto.get(i).getMarca().toUpperCase() + "*****");
            System.out.println("Modelo: " + auto.get(i).getModelo().toUpperCase());
            System.out.println("Precio: " + auto.get(i).getPrecio().toUpperCase());
            System.out.println("Color: " + auto.get(i).getColor().toUpperCase());
            auto.get(i).Encender();
            auto.get(i).Avanzar();
            auto.get(i).Vuelta("izquierda");
            auto.get(i).frenar();
        }

        System.out.println("\nSegunda parte del programa\n");

        ArrayList<Transporte> transporte = new ArrayList<Transporte>(10);
        ArrayList<Automovil> auto1 = new ArrayList<Automovil>(5);
        ArrayList<Tren> tren = new ArrayList<Tren>(5);
        Tren[] maquina = new Tren[5];

        for (int i = 0; i < maquina.length; i++) {
            maquina[i] = new Tren();
            System.out.println("Tren " + (i + 1));
            System.out.print("Marca: ");
            marca = sc.next();
            maquina[i].setMarca(marca);
            System.out.print("Modelo: ");
            modelo = sc.next();
            maquina[i].setModelo(modelo);
            System.out.print("Precio: ");
            precio = sc.next();
            maquina[i].setPrecio(precio);
            System.out.print("Color: ");
            color = sc.next();
            maquina[i].setColor(color);
            System.out.println("");
        }

        transporte.add(coche[0]);
        transporte.add(coche[1]);
        transporte.add(coche[2]);
        transporte.add(coche[3]);
        transporte.add(coche[4]);
        transporte.add(maquina[0]);
        transporte.add(maquina[1]);
        transporte.add(maquina[2]);
        transporte.add(maquina[3]);
        transporte.add(maquina[4]);

        for (Object o : transporte) {
            if (o instanceof Automovil) {
                Automovil a1 = (Automovil) o;
                System.out.println("\n*****AUTOMOVIL " + a1.getMarca().toUpperCase() + "*****");
                System.out.println("Modelo: " + a1.getModelo().toUpperCase());
                System.out.println("Precio: " + a1.getPrecio().toUpperCase());
                System.out.println("Color: " + a1.getColor().toUpperCase());
                a1.Encender();
                a1.Avanzar();
                a1.Vuelta("izquierda");
                a1.frenar();
            } else {
                Tren t1 = (Tren) o;
                System.out.println("\n*****TREN " + t1.getMarca().toUpperCase() + "*****");
                System.out.println("Modelo: " + t1.getModelo().toUpperCase());
                System.out.println("Precio: " + t1.getPrecio().toUpperCase());
                System.out.println("Color: " + t1.getColor().toUpperCase());
                t1.Encender();
                t1.Avanzar();
                t1.Vuelta("izquierda");
                t1.frenar();
            }
        }
    }
}

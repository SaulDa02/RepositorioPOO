
import libreria.operacionesArchivos;

public class runMain9 {

    public static void main(String[] args) {
        operacionesArchivos oA = new operacionesArchivos();
        
        System.out.println("Ingresa dos lineas a escribir en el archivo: ");
        oA.escribirArchivo("Archivo.txt");
        oA.escribirArchivo("Archivo.txt");

        System.out.println("\nArchivo leido: ");
        oA.leerArchivo("Archivo.txt");
    }
}


public class Automovil {

    private String marca;
    private String modelo;
    private String precio;
    private int gas;
    private String movimiento1;
    private String movimiento2;

    Automovil() {
        this("", "", "");
    }
    
    Automovil(String marca, String modelo, String precio) {
        setMarca(marca);
        setModelo(modelo);
        setPrecio(precio);
    }
    
    public int getGas() {
        return gas;
    }

    public void setGas(int gas) {
        this.gas = gas;
    }

    public String getMovimiento1() {
        return movimiento1;
    }

    public void setMovimiento1(String movimiento1) {
        this.movimiento1 = movimiento1;
    }

    public String getMovimiento2() {
        return movimiento2;
    }

    public void setMovimiento2(String movimiento2) {
        this.movimiento2 = movimiento2;
    }
    
    public String getMarca() {
        return marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    public String getPrecio() {
        return precio;
    }
    
    public void setPrecio(String precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Marca: " + this.marca + ". Modelo: " + this.modelo + ". Precio: " + this.precio+". ";
    }
    
    void encender(int gas){
        System.out.println("El auto enciende con "+this.gas+"L de gas. ");
    }
    
    String alto(){
        return "El auto ha parado";
    }
    
    String movimiento1(String mov){
        return "El auto se ha movido: "+this.movimiento1+". ";
    }
    
    String movimiento2(String mov){
        return "El auto se ha movido: "+this.movimiento2+". ";
    }
    
}

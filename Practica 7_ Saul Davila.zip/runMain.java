
public class runMain {

    public static void main(String[] args) {

        LecturaArchivos archivo = new LecturaArchivos();

        Automovil coches[] = new Automovil[10];
        
        archivo.abrirArchivo();
        archivo.leerArchivo();

        for (int i = 0; i < 10; i++) {
            coches[i] = archivo.leerArchivo();
        }

        archivo.cerrarArchivo();
        for (int i = 0; i < 10; i++) {
            System.out.println(coches[i].toString());
            coches[i].encender(coches[i].getGas());
            System.out.println(coches[i].movimiento1(coches[i].getMovimiento1()));
            System.out.println(coches[i].movimiento2(coches[i].getMovimiento2()));
            System.out.println(coches[i].alto());
            System.out.println("");
        }
    }
}

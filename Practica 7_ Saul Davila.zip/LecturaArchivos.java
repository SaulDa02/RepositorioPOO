
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LecturaArchivos {

    File archivo;
    
    private Scanner entrada;

    public void abrirArchivo() {
        try {
            entrada = new Scanner(new File("Autos.txt"));
        } catch (FileNotFoundException ex) {
            System.err.println("No se pudo abrir el archivo");
            System.exit(1);
        }
    }

    public Automovil leerArchivo() {
        Automovil auto = new Automovil();

        while(entrada.hasNext()) {
            auto.setMarca(entrada.next());
            auto.setModelo(entrada.next());
            auto.setPrecio(entrada.next());
            auto.setGas(entrada.nextInt());
            auto.setMovimiento1(entrada.next());
            auto.setMovimiento2(entrada.next());
        return auto;
        }
        return auto;
    }

    public void cerrarArchivo() {
        if (entrada != null) {
            entrada.close();
        }
    }
}


package practica.pkg2;

public class Canario extends Ave{
 
    public void cantar(){
        System.out.println("El Canario canta");
    }
    
}

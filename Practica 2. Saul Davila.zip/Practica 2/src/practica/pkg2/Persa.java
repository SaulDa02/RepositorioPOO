
package practica.pkg2;

public class Persa extends Gato{
    
    public void correr(){
        System.out.println("El Persa corre");
    }
    
}


package practica.pkg2;

public class Ave extends Animal{
    
    private String raza;    

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
    
    public void respirar() {
        super.respirar();
    }

    public void comer(){
        super.comer();
    }
    
    public void volar(){
        System.out.println("El ave vuela");
    }
    
}

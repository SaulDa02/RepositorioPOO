
package practica.pkg2;

public class runMain {
    
    public static void main(String[] args){
        Pastoraleman  pa = new Pastoraleman();
        Chihuahua chi = new Chihuahua();
        Persa persa = new Persa();
        Siames sia = new Siames();
        Canario ca = new Canario();
        Perico per = new Perico();
        
        pa.setCarnivoro("Animal carnivoro");
        System.out.println(pa.getCarnivoro());
        pa.setRaza("Pastor Aleman");
        System.out.println("Raza: "+pa.getRaza());
        pa.respirar();
        pa.comer();
        pa.ladrar();
        pa.caminar();
        pa.correr();
        System.out.println("");
        
        chi.setCarnivoro("Animal carnivoro");
        System.out.println(chi.getCarnivoro());
        chi.setRaza("Chihuahua");
        System.out.println("Raza: "+chi.getRaza());
        chi.respirar();
        chi.comer();
        chi.ladrar();
        chi.caminar();
        chi.correr();
        System.out.println("");
        
        persa.setCarnivoro("Animal carnivoro");
        System.out.println(persa.getCarnivoro());
        persa.setRaza("Persa");
        System.out.println("Raza: "+persa.getRaza());
        persa.respirar();
        persa.comer();
        persa.maullar();
        persa.brincar();
        persa.correr();
        System.out.println("");
        
        sia.setCarnivoro("Animal carnivoro");
        System.out.println(sia.getCarnivoro());
        sia.setRaza("Siames");
        System.out.println("Raza: "+sia.getRaza());
        sia.respirar();
        sia.comer();
        sia.maullar();
        sia.brincar();
        sia.correr();
        System.out.println("");
        
        ca.setCarnivoro("Animal herbivoro");
        System.out.println(ca.getCarnivoro());
        ca.setRaza("Canario");
        System.out.println("Raza: "+ca.getRaza());
        ca.respirar();
        ca.comer();
        ca.volar();
        ca.cantar();
        System.out.println("");
        
        per.setCarnivoro("Animal herbivoro");
        System.out.println(per.getCarnivoro());
        per.setRaza("Perico");
        System.out.println("Raza: "+per.getRaza());
        per.respirar();
        per.comer();
        per.volar();
        per.cantar();
        System.out.println("");
        
    }
    
}

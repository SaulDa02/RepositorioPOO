
package practica.pkg2;

public class Perico extends Ave{
    
    public void cantar(){
        System.out.println("El Perico canta");
    }
    
}


package practica.pkg2;

public class Siames extends Gato{
    
    public void correr(){
        System.out.println("El Siames corre");
    }
    
}

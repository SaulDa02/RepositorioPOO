
package practica.pkg2;

public class Perro extends Animal{
    
    private String raza; 

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }
    
    public void comer() {
        super.comer();
    }
    
    public void respirar() {
        super.respirar();
    }
    
    public void ladrar(){
        System.out.println("El perro ladra");
    }
    
    public void caminar(){
        System.out.println("El perro camina");
    }
    
}

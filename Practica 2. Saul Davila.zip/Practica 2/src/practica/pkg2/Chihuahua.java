
package practica.pkg2;

public class Chihuahua extends Perro{
    
    public void correr(){
        System.out.println("El Chihuahua corre");
    }
}

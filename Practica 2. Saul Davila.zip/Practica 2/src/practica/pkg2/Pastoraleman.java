
package practica.pkg2;

public class Pastoraleman extends Perro{
    
    public void correr(){
        System.out.println("El Pastor Aleman corre");
    }
    
}


public class mainPractica10 {

    public static void main(String[] args) {
        
        Vehiculo v = new Vehiculo();
        Vehiculo v1 = new Vehiculo();
        Vehiculo v2 = new Vehiculo();
        Vehiculo v3 = new Vehiculo();
        Vehiculo v4 = new Vehiculo();
        
        v.setMarca(Vehiculo.Marcas.FORD);
        v.setMatricula("STU-65-22");
        System.out.println("El auto marca "+v.getMarca()+" tiene matricula "+v.getMatricula());
        
        v1.setMarca(Vehiculo.Marcas.TOYOTA);
        v1.setMatricula("SLS-98-54");
        System.out.println("El auto marca "+v1.getMarca()+" tiene matricula "+v1.getMatricula());
        
        v2.setMarca(Vehiculo.Marcas.SUZUKI);
        v2.setMatricula("SGJ-97-14");
        System.out.println("El auto marca "+v2.getMarca()+" tiene matricula "+v2.getMatricula());
        
        v3.setMarca(Vehiculo.Marcas.RENAULT);
        v3.setMatricula("SDH-81-79");
        System.out.println("El auto marca "+v3.getMarca()+" tiene matricula "+v3.getMatricula());
        
        v4.setMarca(Vehiculo.Marcas.SEAT);
        v4.setMatricula("RH-17-049");
        System.out.println("El auto marca "+v4.getMarca()+" tiene matricula "+v4.getMatricula());
        
    }
}

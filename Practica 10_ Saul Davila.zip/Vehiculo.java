
public class Vehiculo {
    
    enum Marcas{
    FORD, TOYOTA, SUZUKI, RENAULT, SEAT;
    }
    
    private String matricula;
    private Marcas marca;

    public Marcas getMarca() {
        return marca;
    }

    public void setMarca(Marcas c) {
        this.marca = c;
    }
    
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
}

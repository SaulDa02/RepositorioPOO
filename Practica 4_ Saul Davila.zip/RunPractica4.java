
package practica.pkg4;

import java.util.Scanner;

public class RunPractica4 {

    public static void main(String[] args) {
        
       FuncioneString funciones = new FuncioneString();
        
       funciones.guiones();
        
       funciones.validarCadenas();
       
       funciones.comprobarSubcadena();
       
       funciones.contarCaracter();
       
       funciones.contarPalabras();
       
       funciones.inicialesMayus();
      
       funciones.invertirCadena();
       
       funciones.sustituirCaracter();
       
       funciones.mayusAMinus();
       
       funciones.cadenaSubcadena();
       
       funciones.palindromo();
    }
    
}

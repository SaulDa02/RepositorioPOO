
package practica.pkg4;

import java.util.Scanner;

public class FuncioneString {
    Scanner scan = new Scanner(System.in);
    
    public void guiones(){
        System.out.println("Funcion para eliminar los guiones de una cadena\n");
        String cadena;
        
        System.out.println("Ingrese una cadena separada por guiones en lugar de espacios: ");
        cadena=scan.next();
        
        System.out.println("Cadena sin guiones: ");
        String[] split = cadena.split("-");
        
        for (int i = 0; i < split.length ; i++) {
            System.out.print(split[i]+" ");
        }
        System.out.println("\n----------------------------------------------------------------\n");
    }
    
    public void validarCadenas(){
        System.out.println("Funcion validar igualdad de dos cadenas\n");
        String cad1;
        String cad2;
        
        System.out.println("Ingrese la cadena 1: ");
        cad1 = scan.nextLine();
        System.out.println("Ingrese la cadena 2: ");
        cad2 = scan.nextLine();
        
        boolean termina = cad1.endsWith(cad2);
        boolean empieza = cad1.startsWith(cad2);
        
        if (empieza==true && termina==true){
            System.out.println("Ambas cadenas son iguales. ");
        }else{
            System.out.println("Las cadenas son diferentes");
        }
        System.out.println("----------------------------------------------------------------\n");
    }
    
    public void comprobarSubcadena(){
        System.out.println("Funcion empiezaCon/terminaCon subcadenas\n");
        String cadena1, cadena2;
        
        System.out.println("Ingrese la cadena base: ");
        cadena1 = scan.nextLine();
        System.out.println("Ingrese la subcadena: ");
        cadena2 = scan.nextLine();
        
        boolean termina = cadena1.endsWith(cadena2);
        boolean empieza = cadena1.startsWith(cadena2);
        
        if (empieza==true){
            System.out.println("\nLa cadena 1 empieza con la cadena 2");
        }else{
            System.out.println("\nLa cadena 1 no empieza con la cadena 2");
        }
        if (termina==true){
            System.out.println("La cadena 1 termina con la cadena 2");
        }else{
            System.out.println("La cadena 1 no termina con la cadena 2");
        }
        System.out.println("----------------------------------------------------------------\n");
    }
   
    public void contarCaracter(){
        System.out.println("Funcion contar veces que sale un caracter en una cadena de caracteres\n");
        String cadena;
        char car;
        int contador=0;
        
        System.out.print("Ingrese una cadena de caracteres:\n");
        cadena = scan.nextLine();
        System.out.println("Caracter elegido: ");
        do{
            car = scan.next().charAt(0);
        }while((car<65 || car>90 && car<97 || car>122));
        
        char[] arreglo = cadena.toCharArray();
        
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i]==car){
                contador+=1;
            }
        }
        System.out.println("\nNumero de veces que aparece en el arreglo: "+contador);
        System.out.println("----------------------------------------------------------------\n");
    }
    
    
    public void contarPalabras(){
        System.out.println("Funcion contar palabras en una cadena de caracteres\n");
        String cadena;
        int contador=0;
        System.out.println("Ingrese una oración: ");
        cadena = scan.nextLine();
        
        String[] split = cadena.split(" ");
        
        for (int i = 0; i < split.length ; i++) {
            
            contador+=1;
        }
        System.out.println("Palabras en la oración: "+contador);
        System.out.println("----------------------------------------------------------------\n");
    }
    
    public void inicialesMayus(){
        System.out.println("Funcion colocar en mayuscula cada primer letra del nombre\n");
        String cadena;
        System.out.println("Escribe tu nombre completo en minúsculas: ");
        cadena = scan.nextLine();
        
        String[] split = cadena.split(" ");
        
        System.out.println("\nNombre completo: ");
        
        for (int i = 0; i < split.length ; i++) {
            split[i]= split[i].substring(0, 1).toUpperCase()+split[i].substring(1);
            System.out.print(split[i]+" ");
        }
        System.out.println("\n----------------------------------------------------------------\n");
    }
    
    public void invertirCadena(){
        System.out.println("Funcion invertir una cadena de caracteres\n");
        String cadena;
        
        System.out.print("Escribe una cadena de caracteres: ");
        cadena = scan.nextLine();
        
        char[] caracteres = cadena.toCharArray();
        
        System.out.print("\nCadena invertida: ");
        for (int i = caracteres.length-1; i >=0; i--) {
            System.out.print(caracteres[i]);
        }
        System.out.println("\n----------------------------------------------------------------\n");
    }
    
    public void sustituirCaracter(){
        System.out.println("Funcion sustituir un caracter por otro en toda la cadena\n");
        String cadena;
        char car1, car2;
        
        System.out.print("Ingrese una oracion: ");
        cadena = scan.nextLine();
        System.out.println("Ingrese el caracter a reemplazar: ");
        car1 = scan.next().charAt(0);
        System.out.println("Ingrese el caracter por el cual reemplazar: ");
        car2 = scan.next().charAt(0);
        
        cadena= cadena.replace(car1, car2);
        System.out.println("Cadena nueva: "+cadena);
        System.out.println("\n----------------------------------------------------------------\n");
    }
    
    public void mayusAMinus(){
        System.out.println("Funcion cambiar minusculas a mayusculas y visceversa\n");
        String cadena;
        String cambiado;
        
        System.out.print("Programa para convertir mayusculas a minusculas y visceversa\nIngrese una cadena de caracteres: ");
        cadena = scan.nextLine();
        
        System.out.println("Cadena en mayusculas: ");
        System.out.println(cadena.toUpperCase());
        
        System.out.println("Cadena en minusculas: ");
        System.out.println(cadena.toLowerCase());
        System.out.println("\n----------------------------------------------------------------\n");
    }

    public void cadenaSubcadena(){
        System.out.println("Funcion encontrar si es subcadena de otra\n");
        String cadena1, cadena2;
        
        System.out.print("Introduzca la primer cadena de caracteres: ");
        cadena1 = scan.nextLine();
        System.out.print("Introduzca la segunda cadena de caracteres: ");
        cadena2 = scan.nextLine();
        
        Boolean contiene = cadena1.contains(cadena2);
        
        if (contiene==true) {
            System.out.println("\nLa cadena 1 contiene a la cadena 2");
        } else {
            System.out.println("\nLa cadena 1 no contiene a la cadena 2");  
        }
        System.out.println("\n----------------------------------------------------------------\n");
    }
    
    public void palindromo(){
        System.out.println("Funcion conocer si una cadena es palindromo\n");
        String cadena;
        int contador=0;
        
        System.out.print("Escribe una cadena de caracteres: ");
        cadena = scan.nextLine();
        
        char[] caracteres = cadena.toCharArray();
        char[] palindromo = cadena.toCharArray();
                
        for (int i = caracteres.length-1; i >=0; i--) {   
            palindromo[contador]=caracteres[i];   
            contador++;
        }
        String pal = new String(palindromo);
        
        boolean comparar = cadena.equalsIgnoreCase(pal);
        
        if (comparar==true) {
            System.out.println("La cadena es palindromo. ");
        }else{
            System.out.println("La cadena no es palindromo. ");
        }
        System.out.println("\n----------------------------------------------------------------\n");
    }
}
